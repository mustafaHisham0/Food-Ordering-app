
package main;

class Customer {
    private String name;
    private String phone;
    private Address address; // Modeled using composition

    // The constructor takes address details and creates the Address object itself
    public Customer(String name, String phone, String street, String district, String city) {
        this.name = name;
        this.phone = phone;
        this.address = new Address(street, district, city);
    }

    public String getName() {
        return name;
    }

    public Address getAddress() {
        return address;
    }

    @Override
    public String toString() {
        return name + " (" + phone + ")\nAddress: " + address.toString();
    }
}
