
package main;

import java.util.ArrayList;
import java.util.List;

class ItemNotFoundException extends Exception {
    public ItemNotFoundException(String message) {
        super(message);
    }
}

class InvalidQuantityException extends Exception {
    public InvalidQuantityException(String message) {
        super(message);
    }
}

class MinimumOrderException extends Exception {
    public MinimumOrderException(String message) {
        super(message);
    }

    
    
public class Main {
    public static void main(String[] args) {
        System.out.println("--- Restaurant Order System Test ---");

        // 1. Create two customers (Address is created strictly inside the constructor)
        Customer c1 = new Customer("Alice Smith", "555-0101", "Main St", "Kadikoy", "Istanbul");
        Customer c2 = new Customer("Bob Johnson", "555-0202", "Park Ave", "Cankaya", "Ankara");

        // 2. Create coupons
        Coupon bigDiscount = new Coupon("SAVE50", 0.50, 200.0); // 50% off if subtotal >= 200
        Coupon smallDiscount = new Coupon("SAVE10", 0.10, 50.0); // 10% off if subtotal >= 50

        try {
            // --- ORDER 1: Testing Successful Checkout with Applied Coupon ---
            System.out.println("\n>>> Creating Order 1");
            Order order1 = new Order(c1);
            order1.addItem(new MenuItem("Pizza", 120.0, 1));
            order1.addItem(new MenuItem("Cola", 30.0, 2));
            order1.addItem(new MenuItem("Pizza", 120.0, 1)); // Adding the same item twice -> increases quantity to 2

            // Update quantity of Cola
            order1.updateQuantity("Cola", 3);
            
            // Remove an item to test the functionality (let's add a dummy item and remove it)
            order1.addItem(new MenuItem("Salad", 40.0, 1));
            order1.removeItem("Salad");

            // Subtotal will be: (120*2) + (30*3) = 330 TL. 
            // Min subtotal for bigDiscount is 200 TL. Coupon SHOULD be applied.
            order1.applyCoupon(bigDiscount); 
            order1.checkout();

            // Attempting to checkout a completed order again
            order1.checkout(); 


         
            System.out.println(">>> Creating Order 2");
            Order order2 = new Order(c2);
            order2.addItem(new MenuItem("Burger", 110.0, 1)); 
            
            // Subtotal is 110 TL. Min subtotal for bigDiscount is 200 TL. 
            // Coupon SHOULD NOT be applied.
            order2.applyCoupon(bigDiscount);
            order2.checkout();

        } catch (Exception e) {
            System.out.println("Unexpected exception in happy paths: " + e.getMessage());
        }

        System.out.println("\n>>> Testing Custom Exceptions (Try-Catch blocks)");

        // --- EXCEPTION 1: MinimumOrderException ---
        try {
            Order errorOrder1 = new Order(c1);
            errorOrder1.addItem(new MenuItem("Water", 10.0, 2)); 
            // Subtotal 20 TL < 100 TL MIN_ORDER
            errorOrder1.checkout();
        } catch (MinimumOrderException e) {
            System.out.println("[Caught Expected Exception] MinimumOrderException: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Caught wrong exception!");
        }

        // --- EXCEPTION 2: InvalidQuantityException ---
        try {
            MenuItem invalidItem = new MenuItem("Fries", 40.0, 0); // Triggers exception immediately
        } catch (InvalidQuantityException e) {
            System.out.println("[Caught Expected Exception] InvalidQuantityException: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Caught wrong exception!");
        }

        // --- EXCEPTION 3: ItemNotFoundException ---
        try {
            Order errorOrder3 = new Order(c2);
            errorOrder3.addItem(new MenuItem("Pasta", 80.0, 1));
            errorOrder3.removeItem("Steak"); // Item doesn't exist
        } catch (ItemNotFoundException e) {
            System.out.println("[Caught Expected Exception] ItemNotFoundException: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Caught wrong exception!");
        }

       
        System.out.println("\n>>> System Statistics <<<");
        System.out.println("Total Completed Orders: " + Order.getCompletedOrders());
        System.out.println("Total System Revenue: " + Order.getTotalRevenue() + " TL");
    }
}
}