
package main;

import java.util.ArrayList;

class Order {
    private Customer customer;
    private ArrayList<MenuItem> items;
    private Coupon coupon;
    private int orderNumber;
    private boolean isCompleted;

    // Static variables
    private static int nextOrderNumber = 1001;
    public static final double MIN_ORDER = 100.0;
    public static final double DELIVERY_FEE = 20.0;
    
    private static int completedOrders = 0;
    private static double totalRevenue = 0.0;

    public Order(Customer customer) {
        this.customer = customer;
        this.items = new ArrayList<>();
        this.orderNumber = nextOrderNumber++; // Assign and increment
        this.isCompleted = false;
    }

    public void addItem(MenuItem item) throws InvalidQuantityException {
        // If an item with the same name is already in the order, increase its quantity
        for (MenuItem existingItem : items) {
            if (existingItem.getName().equalsIgnoreCase(item.getName())) {
                existingItem.setQuantity(existingItem.getQuantity() + item.getQuantity());
                return;
            }
        }
        // Otherwise add the new item
        items.add(item);
    }

    public void removeItem(String name) throws ItemNotFoundException {
        boolean removed = items.removeIf(item -> item.getName().equalsIgnoreCase(name));
        if (!removed) {
            throw new ItemNotFoundException("Item '" + name + "' is not in the order.");
        }
    }

    public void updateQuantity(String name, int quantity) throws ItemNotFoundException, InvalidQuantityException {
        for (MenuItem item : items) {
            if (item.getName().equalsIgnoreCase(name)) {
                item.setQuantity(quantity);
                return;
            }
        }
        throw new ItemNotFoundException("Item '" + name + "' is not in the order. Cannot update quantity.");
    }

    public double getSubtotal() {
        double subtotal = 0;
        for (MenuItem item : items) {
            subtotal += item.getTotalPrice();
        }
        return subtotal;
    }

    public ArrayList<MenuItem> getItems() {
        // Return a copy of the items so the order cannot be changed from outside
        return new ArrayList<>(items);
    }

    public void applyCoupon(Coupon coupon) {
        this.coupon = coupon;
    }

    public double checkout() throws MinimumOrderException {
        if (isCompleted) {
            System.out.println("Error: Order #" + orderNumber + " is already completed and cannot be checked out again.");
            return 0.0;
        }

        double subtotal = getSubtotal();
        if (subtotal < MIN_ORDER) {
            throw new MinimumOrderException("Subtotal (" + subtotal + " TL) is less than the minimum order amount of " + MIN_ORDER + " TL.");
        }

        double discountAmount = 0.0;
        // The discount is applied only if the subtotal is at least minSubtotal
        if (coupon != null && subtotal >= coupon.getMinSubtotal()) {
            discountAmount = subtotal * coupon.getDiscountRate();
        }

        double total = subtotal - discountAmount + DELIVERY_FEE;

        // Print receipt
        System.out.println("\n================ RECEIPT ================");
        System.out.println("Order Number: " + orderNumber);
        System.out.println("Customer: " + customer.getName());
        System.out.println("Address: " + customer.getAddress().toString());
        System.out.println("-----------------------------------------");
        System.out.println("Items:");
        for (MenuItem item : items) {
            System.out.println("- " + item.toString());
        }
        System.out.println("-----------------------------------------");
        System.out.printf("Subtotal: %.2f TL\n", subtotal);
        if (discountAmount > 0) {
            System.out.printf("Coupon Discount (%s): -%.2f TL\n", coupon.getCode(), discountAmount);
        } else if (coupon != null) {
            System.out.println("Coupon Discount: 0.00 TL (Minimum subtotal not reached for coupon)");
        }
        System.out.printf("Delivery Fee: %.2f TL\n", DELIVERY_FEE);
        System.out.printf("TOTAL: %.2f TL\n", total);
        System.out.println("=========================================\n");

        // Update static statistics
        isCompleted = true;
        completedOrders++;
        totalRevenue += total;

        return total;
    }

    // Static getters
    public static int getCompletedOrders() {
        return completedOrders;
    }

    public static double getTotalRevenue() {
        return totalRevenue;
    }
}

