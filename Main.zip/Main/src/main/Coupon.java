/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;


class Coupon {
    private String code;
    private double discountRate;
    private double minSubtotal;

    public Coupon(String code, double discountRate, double minSubtotal) {
        this.code = code;
        this.minSubtotal = minSubtotal;
        // Discount rate is at most 50%
        if (discountRate > 0.50) {
            this.discountRate = 0.50;
        } else if (discountRate < 0) {
            this.discountRate = 0.0;
        } else {
            this.discountRate = discountRate;
        }
    }

    public double getDiscountRate() {
        return discountRate;
    }

    public double getMinSubtotal() {
        return minSubtotal;
    }
    
    public String getCode() {
        return code;
    }
}
